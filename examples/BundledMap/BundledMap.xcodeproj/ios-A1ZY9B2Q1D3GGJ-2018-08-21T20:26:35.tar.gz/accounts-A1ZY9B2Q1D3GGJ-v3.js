var venueInfos = {
    "sea": {
        "airportCode": "sea",
        "assetVersion": "2018-08-21T20:26:35",
        "id": "sea",
        "locale": "en",
        "name": "Seattle-Tacoma International Airport"
    }
};
locuslabs.reduxStore.dispatch({ type: 'VENUE_LIST_LOADER/VENUE_LIST_LOADED_BY_SCRIPT', venueList: venueInfos });